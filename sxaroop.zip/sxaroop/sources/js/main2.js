/* script.js — mobile nav + small UI interactions */

const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

document.addEventListener('DOMContentLoaded', () => {
  // year
  const yearEl = $('#year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const menuToggle = $('#menuToggle');
  const mobileNav = $('#mobileNav');
  const mobileOverlay = $('#mobileOverlay');
  const mobileClose = $('#mobileClose') || $('#mobileClose');
  const mobileLinks = $$('.mobile-list a');
  const internalLinks = $$('[data-scroll]');

  // Utility to open/close mobile nav
  function setMobileOpen(isOpen) {
    if (!mobileNav || !mobileOverlay) return;
    mobileNav.setAttribute('aria-hidden', String(!isOpen));
    menuToggle?.setAttribute('aria-expanded', String(isOpen));
    mobileOverlay.dataset.hidden = String(!isOpen);
    // prevent background scroll when open
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      mobileOverlay.setAttribute('aria-hidden', 'false');
    } else {
      document.body.style.overflow = '';
      mobileOverlay.setAttribute('aria-hidden', 'true');
    }
  }

  // initial ensure closed
  setMobileOpen(false);

  menuToggle?.addEventListener('click', () => {
    const isOpen = mobileNav.getAttribute('aria-hidden') === 'false';
    setMobileOpen(!isOpen);
  });

  // overlay click closes menu
  mobileOverlay?.addEventListener('click', () => setMobileOpen(false));
  // mobile close button
  $('#mobileClose')?.addEventListener('click', () => setMobileOpen(false));

  // clicking a mobile link should close the menu and navigate smoothly
  mobileLinks.forEach(a => {
    a.addEventListener('click', (e) => {
      // smooth scroll handled elsewhere — close menu first
      setMobileOpen(false);
      // leave default link behavior (anchor) — smooth scroll below intercepts it
    });
  });

  // Smooth scroll for all [data-scroll] anchors
  internalLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (!href || !href.startsWith('#')) return;
      e.preventDefault();
      const target = document.querySelector(href);
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // close mobile nav if open
      if (mobileNav && mobileNav.getAttribute('aria-hidden') === 'false') {
        setMobileOpen(false);
      }
    });
  });

  // contact form minimal validation & mock submit
  const form = $('#contactForm');
  const note = $('#formNote');
  if (form) {
    form.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const name = $('#name')?.value?.trim();
      const email = $('#email')?.value?.trim();
      const message = $('#message')?.value?.trim();
      if (!name || !email || !message) {
        if (note) { note.textContent = 'Please complete all fields.'; note.style.color = 'tomato'; }
        return;
      }
      if (!/^\S+@\S+\.\S+$/.test(email)) {
        if (note) { note.textContent = 'Please enter a valid email.'; note.style.color = 'tomato'; }
        return;
      }
      if (note) { note.textContent = 'Sending...'; note.style.color = 'inherit'; }
      // mock async
      setTimeout(() => {
        if (note) { note.textContent = 'Message sent — thank you!'; note.style.color = 'lightgreen'; }
        form.reset();
      }, 900);
    });
  }

  // modal escape close
  document.addEventListener('keydown', (e) => {
    const modal = $('#projectModal');
    if (!modal) return;
    if (e.key === 'Escape' && modal.getAttribute('aria-hidden') === 'false') {
      modal.setAttribute('aria-hidden', 'true');
    }
  });
});