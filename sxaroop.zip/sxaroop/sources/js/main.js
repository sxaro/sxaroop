// Created By SwaroopJangid | Developer & Creative Frontend Creator
// Main functions starts from here!
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

document.addEventListener('DOMContentLoaded', () => {
  // set year
  $('#year').textContent = new Date().getFullYear();

  // mobile menu toggle
  const menuToggle = $('#menuToggle');
  const mobileNav  = $('#mobileNav');
  menuToggle?.addEventListener('click', () => {
    const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!expanded));
    mobileNav.setAttribute('aria-hidden', String(expanded));
  });

  // Smooth scroll for internal links with data-scroll
  $$('[data-scroll]').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const href = this.getAttribute('href') || '#';
      const target = document.querySelector(href);
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // close mobile nav if open
      if (mobileNav && mobileNav.getAttribute('aria-hidden') === 'false') {
        mobileNav.setAttribute('aria-hidden', 'true');
        menuToggle.setAttribute('aria-expanded','false');
      }
    });
  });

  // Typing effect for subheading (simple)
  const subtitle = document.querySelector('.hero-sub');
  if (subtitle) {
    const phrases = ['A Web Developer', 'Frontend Engineer', 'UI Enthusiast'];
    let pi = 0, ch = 0, dir = 1;
    setInterval(() => {
      subtitle.textContent = phrases[pi].slice(0, ch);
      ch += dir;
      if (ch > phrases[pi].length) { dir = -1; ch = phrases[pi].length - 1; setTimeout(()=>{ dir= -1; },800); }
      if (ch <= 0) { dir = 1; pi = (pi+1)%phrases.length; }
    }, 120);
  }

  // lazy image reveal (fade-in)
  const lazyImgs = $$('.lazy');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('revealed');
      io.unobserve(entry.target);
    });
  }, { threshold: 0.1 });
  lazyImgs.forEach(img => io.observe(img));

  // Portfolio modal opener
  const projectLinks = $$('[data-project]');
  const modal = $('#projectModal');
  projectLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const id = link.getAttribute('data-project');
      openProjectModal(id);
    });
  });
  // modal close
  $('.modal-close')?.addEventListener('click', closeProjectModal);
  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeProjectModal();
  });
  // Yeha 100% Energy Use Ho Gayi!
  function openProjectModal(id){
    // minimal mocked content (in real site fetch or fill details)
    // first
    $('#projectModalTitle').textContent = `Project ${id} — Case Study`;
    $('#projectModalDesc').textContent = `This is a short description for project ${id}. Seamlessly blending Node.js, MongoDB, HTML, and CSS with live terminal updates, this setup delivers a powerful and professional environment for building, testing, and deploying modern web applications.`;
    // break code input
    $('#projectModalLink').setAttribute('href', '#',);
    modal.setAttribute('aria-hidden', 'false');
    // second
    $('#projectModalTitle').textContent = `Project ${id} — Case Study`;
    $('#projectModalDesc').textContent = `This is a short description for project ${id}. Unlock the power of seamless deployment with secure environment variables! This setup keeps your API keys, tokens, and secrets safe while fueling powerful integrations like OpenAI. Designed for developers who value both innovation and security, it creates the perfect foundation for building scalable, reliable, and professional-grade applications.`;
    // break code input 2
    $('#projectModalLink').setAttribute('href', '#');
    modal.setAttribute('aria-hidden', 'false');
    // third
    $('#projectModalTitle').textContent = `Project ${id} — Case Study`;
    $('#projectModalDesc').textContent = `This is a short description for project ${id}. Instagram API setup on Meta for developers, enabling access token generation, webhook configuration, business login, and app review. It provides a secure way to connect apps with Instagram data for automation and integrations.`;
    // break code input 3
    $('#projectModalLink').setAttribute('href', '#');
    modal.setAttribute('aria-hidden', 'false');
  }
  function closeProjectModal(){
    modal.setAttribute('aria-hidden', 'true');
  }

  // simple testimonial auto-scroll (carousel)
  const ts = $('#testimonials');
  if (ts) {
    let offset = 0;
    setInterval(() => {
      offset = (offset + 320);
      if (offset > ts.scrollWidth - ts.clientWidth) { offset = 0; }
      ts.scrollTo({ left: offset, behavior: 'smooth' });
    }, 4000);
  }

  // Contact form validation + mocked submit
  const form = $('#contactForm');
  const formNote = $('#formNote');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = $('#name').value.trim();
      const email = $('#email').value.trim();
      const message = $('#message').value.trim();
      if (!name || !email || !message) {
        formNote.textContent = 'Please fill all fields.';
        formNote.style.color = 'tomato';
        return;
      }
      // basic email pattern
      if (!/^\S+@\S+\.\S+$/.test(email)) {
        formNote.textContent = 'Please enter a valid email.';
        formNote.style.color = 'tomato';
        return;
      }

      // mock async send (here you'd call your backend)
      formNote.textContent = 'Sending...';
      formNote.style.color = 'var(--muted)';
      setTimeout(() => {
        formNote.textContent = 'Message sent — thank you!';
        formNote.style.color = 'lightgreen';
        form.reset();
      }, 1100);
    });
  }

  // small accessibility improvement: trap focus when modal open
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal && modal.getAttribute('aria-hidden') === 'false') {
      closeProjectModal();
    }
  });

  // subtle attention-grabbing bounce for CTA on load
  const cta = $('#ctaTop');
  if (cta) {
    setTimeout(()=> {
      cta.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(-6px)' }, { transform: 'translateY(0)' }], { duration: 900, iterations: 1 });
    }, 900);
  }
});

// Zoom Image Code!
document.addEventListener("DOMContentLoaded", () => {
  const imgs = document.querySelectorAll("#portfolio .lazy");
  let overlay = null;
  let escHandler = null;

  function closeZoom() {
    const zoomed = document.querySelectorAll("#portfolio .lazy.zoomed");
    zoomed.forEach(img => img.classList.remove("zoomed"));
    if (overlay) {
      overlay.classList.remove("visible");
      overlay.addEventListener("transitionend", () => { if (overlay) overlay.remove(); }, { once: true });
      overlay = null;
    }
    document.body.style.overflow = "";
    if (escHandler) {
      document.removeEventListener("keydown", escHandler);
      escHandler = null;
    }
  }

  imgs.forEach(img => {
    img.addEventListener("click", (e) => {
      e.stopPropagation();

      // If clicked image is already zoomed — close
      if (img.classList.contains("zoomed")) {
        closeZoom();
        return;
      }

      // Close any other zoomed image
      closeZoom();

      // Create overlay
      overlay = document.createElement("div");
      overlay.className = "img-overlay";
      document.body.appendChild(overlay);
      // allow CSS transition to take effect
      requestAnimationFrame(() => overlay.classList.add("visible"));

      // Show zoomed image
      img.classList.add("zoomed");

      // disable background scroll
      document.body.style.overflow = "hidden";

      // close handlers
      overlay.addEventListener("click", closeZoom);

      escHandler = (ev) => { if (ev.key === "Escape") closeZoom(); };
      document.addEventListener("keydown", escHandler);
    });
  });

  // also close on page click (just in case)
  document.addEventListener("click", (e) => {
    // If clicked outside any project-card and something is zoomed, close it
    if (!e.target.closest(".project-card") && document.querySelector("#portfolio .lazy.zoomed")) {
      closeZoom();
    }
  });
});

// SxaroopJangid